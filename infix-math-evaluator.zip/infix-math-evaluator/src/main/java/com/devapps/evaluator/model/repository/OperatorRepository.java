package com.devapps.evaluator.model.repository;

import com.devapps.evaluator.model.entity.Operator;
import org.springframework.data.repository.CrudRepository;


public interface OperatorRepository extends CrudRepository<Operator,String>
{
    Operator findByOperator (String symbol);

    Operator findByOperatorAndApply (String symbol,String apply);

}
