package com.devapps.evaluator.domain.process;

import com.devapps.evaluator.domain.repository.Evaluator;
import com.devapps.evaluator.domain.repository.GetExpression;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

@Service
public class InFixEvaluator implements GetExpression<String>,Evaluator<Integer,String>
{
    private Environment env;
    private Logger log;
    private GetExpression<String> postExpression;
    private Evaluator<Integer,String> evaluator;

    @Autowired
    public InFixEvaluator(Environment env, GetExpression<String> postExpression,Evaluator<Integer,String> evaluator)
    {
        this.env = env;
        this.log = LoggerFactory.getLogger(getClass());
        this.postExpression = postExpression;
        this.evaluator = evaluator;
    }


    @Override
    public Integer evaluation(String expression)
    {
        return evaluator.evaluation(expression);
    }

    @Override
    public String getPostFixExpression(String inFix)
    {
        return postExpression.getPostFixExpression(inFix);
    }
}
