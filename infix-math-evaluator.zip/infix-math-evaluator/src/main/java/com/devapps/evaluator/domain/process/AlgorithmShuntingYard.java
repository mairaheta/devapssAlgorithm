package com.devapps.evaluator.domain.process;

import com.devapps.evaluator.domain.repository.GetExpression;
import com.devapps.evaluator.model.entity.Operator;
import com.devapps.evaluator.model.repository.OperatorRepository;

public class AlgorithmShuntingYard implements GetExpression<String>
{
    private OperatorRepository operators;

    public AlgorithmShuntingYard(OperatorRepository operators)
    {
        this.operators = operators;
    }

    @Override
    public String getPostFixExpression(String inFix)
    {

        return null;
    }

    private boolean isOperator(String token) {
        Operator op = operators.findByOperator(token);
        boolean result;

        if (op != null)
        {
            result = true;
        }
        else
        {
            result = false;
        }

        return result;
    }


}
