package com.devapps.evaluator.domain.repository;

public interface Evaluator<U,T>
{
    public U evaluation(T expression);
}
