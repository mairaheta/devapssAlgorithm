package com.devapps.evaluator.domain.exception;

import com.devapps.evaluator.model.exception.MathException;
import com.devapps.evaluator.pojo.FailResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
@RestController
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler
{
    private ExceptionResponse excepResponse;

    public GlobalExceptionHandler(ExceptionResponse excepResponse)
    {
        this.excepResponse = excepResponse;
    }

    @ExceptionHandler(MathException.class)
    public final ResponseEntity<FailResponse> handlerMathFoundException(MathException ex, WebRequest request) {
        FailResponse errorDetails = excepResponse.getMathError(ex.getMessage());
        return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(Exception.class)
    public final ResponseEntity<FailResponse> handlerAnyException(Exception ex, WebRequest request) {
        FailResponse errorDetails = excepResponse.getAnyError();
        return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
