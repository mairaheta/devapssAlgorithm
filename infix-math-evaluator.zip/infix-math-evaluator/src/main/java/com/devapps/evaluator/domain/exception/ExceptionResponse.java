package com.devapps.evaluator.domain.exception;

import com.devapps.evaluator.pojo.FailResponse;

public interface ExceptionResponse
{
    public FailResponse getMathError (String expression);
    public FailResponse getAnyError ();

}
