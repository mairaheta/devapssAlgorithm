package com.devapps.evaluator.domain.exception;

import com.devapps.evaluator.pojo.FailResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;

public class EvaluatorExceptionResponse implements ExceptionResponse
{
    private Environment env;
    private Logger log;
    private String mathMsg;
    private String anyMsg;

    public EvaluatorExceptionResponse(Environment env)
    {
        this.env = env;
        this.log = LoggerFactory.getLogger(getClass());
        this.mathMsg = env.getProperty("service.exception.message.math");
        this.anyMsg = env.getProperty("service.exception.message.any");
    }

    @Override
    public FailResponse getMathError(String expression)
    {
        log.info("Error Math");
        FailResponse response = new FailResponse();

        response.setMessage(mathMsg.replace("[INFIX]",expression));

        return response;
    }

    @Override
    public FailResponse getAnyError()
    {
        log.info("Error General");
        FailResponse response = new FailResponse();

        response.setMessage(anyMsg);

        return response;
    }

}
