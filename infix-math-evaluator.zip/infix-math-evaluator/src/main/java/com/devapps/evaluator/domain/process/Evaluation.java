package com.devapps.evaluator.domain.process;

import com.devapps.evaluator.model.exception.MathException;
import com.devapps.evaluator.pojo.SuccessResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

@Service
public class Evaluation
{
    private Environment env;
    private Logger log;
    private InFixEvaluator eval;

    @Autowired
    public Evaluation(Environment env,InFixEvaluator eval)
    {
        this.env = env;
        this.log = LoggerFactory.getLogger(getClass());
        this.eval = eval;
    }

    public SuccessResponse perfomEvaluation (String expression) throws MathException
    {
        SuccessResponse response = new SuccessResponse();

        String posFix = eval.getPostFixExpression(expression);
        int result = eval.evaluation(posFix);

        response.setInfix(expression);
        response.setPostfix(posFix);
        response.setResult(result);

        return response;
    }
}
