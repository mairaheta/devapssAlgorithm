package com.devapps.evaluator.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "infix",
        "postfix",
        "result"
})
public class SuccessResponse
{
    @JsonProperty("infix")
    private String infix;
    @JsonProperty("postfix")
    private String postfix;
    @JsonProperty("result")
    private int result;

    @JsonProperty("infix")
    public String getInfix() {
        return infix;
    }

    @JsonProperty("infix")
    public void setInfix(String infix) {
        this.infix = infix;
    }

    @JsonProperty("postfix")
    public String getPostfix() {
        return postfix;
    }

    @JsonProperty("postfix")
    public void setPostfix(String postfix) {
        this.postfix = postfix;
    }

    @JsonProperty("result")
    public int getResult() {
        return result;
    }

    @JsonProperty("result")
    public void setResult(int result) {
        this.result = result;
    }

}
