package com.devapps.evaluator.controller;

import com.devapps.evaluator.domain.process.Evaluation;
import com.devapps.evaluator.model.exception.MathException;
import com.devapps.evaluator.pojo.InputRequest;
import com.devapps.evaluator.pojo.SuccessResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@PropertySource("classpath:application.properties")
public class EvaluateController
{
    private Environment env;
    private Logger log;
    private Evaluation evaluator;

    EvaluateController(Environment env, Evaluation evaluator)
    {
        this.env = env;
        this.log = LoggerFactory.getLogger(getClass());
        this.evaluator = evaluator;
    }

    @PostMapping("${service.url.endpoint.evaluate}")
    public SuccessResponse evaluate (@RequestBody InputRequest request) throws MathException
    {
        return evaluator.perfomEvaluation(request.getExp());
    }
}
