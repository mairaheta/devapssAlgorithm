package com.devapps.evaluator.domain.repository;

public interface GetExpression<T>
{
    public T getPostFixExpression(String inFix);
}
