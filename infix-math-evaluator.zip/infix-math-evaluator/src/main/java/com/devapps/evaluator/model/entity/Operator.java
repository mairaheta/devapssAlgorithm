package com.devapps.evaluator.model.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name = "operators")
@Data
public class Operator
{
    @Id
    @Column(name = "id")
    private Integer idcode;

    @Column(name = "operators")
    private String operator;

    @Column(name = "precedence")
    private Integer precedence;

    @Column(name="apply")
    private String apply;

}
