package com.devapps.evaluator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InfixMathEvaluatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(InfixMathEvaluatorApplication.class, args);
	}

}
