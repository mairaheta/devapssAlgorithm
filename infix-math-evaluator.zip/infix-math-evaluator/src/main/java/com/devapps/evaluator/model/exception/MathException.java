package com.devapps.evaluator.model.exception;

public class MathException extends Exception
{
    private final String expression;

    public MathException(String message)
    {
        super();
        this.expression = message;
    }

    public String getExpression() {
        return expression;
    }
}
