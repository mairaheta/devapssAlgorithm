package com.devapps.evaluator.domain.process;

import com.devapps.evaluator.MockEnv;
import com.devapps.evaluator.model.exception.MathException;
import com.devapps.evaluator.pojo.SuccessResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

class EvaluationTest
{
    private MockEnv mockEnv = new MockEnv();
    private Evaluation evaluation;
    private static String postExp;
    private static String intExp;
    private static int result;
    private static SuccessResponse sucessR;

    @BeforeClass
    public static void configuration()
    {
        String postExp = "34+";
        int result = 7;
        String intExp = "3+4";

        sucessR = new SuccessResponse();
        sucessR.setPostfix(postExp);
        sucessR.setInfix(intExp);
        sucessR.setResult(result);

    }

    private String objToString(Object o)
    {
        ObjectMapper mapper = new ObjectMapper();
        try {
            return mapper.writeValueAsString(o);
        }catch (Exception e){
            return null;
        }
    }

    @Test
    void successEvaluation() throws MathException
    {
        InFixEvaluator eval = Mockito.mock(InFixEvaluator.class);
        Mockito
                .when(eval.getPostFixExpression(Mockito.anyString()))
                .thenReturn(postExp)
        ;
        Mockito
                .when(eval.evaluation(Mockito.anyString()))
                .thenReturn(result)
        ;

        evaluation = new Evaluation(mockEnv,eval);

        SuccessResponse respuesta = evaluation.perfomEvaluation("3+4");

        Assert.assertEquals(objToString(respuesta),objToString(sucessR));

    }
}